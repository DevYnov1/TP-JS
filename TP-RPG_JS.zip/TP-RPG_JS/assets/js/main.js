$('document').ready(function() {
    $('#Instructions').click(function(){
    $('.menu').toggleClass('menu_open'); 
    });
  
    let nomhero = 'Pseudo';
    let racehero = 'naruto';
    let classehero = 'Taijutsu';
    let lvl = 1;
    let spritehero = '';
    let str_reroll = 0;
    let dex_reroll = 0;
    let int_reroll = 0;
    let con_reroll = 0;
    let rerollstat = 3;
    let str = 0;
    let dex = 0
    let con = 0;
    let int = 0;
    let str_base = 50;
    let dex_base = 50;
    let con_base = 50;// pour test plus rapidement
    let int_base = 50;
    let pdv = 1;
    let mana = 0;
    let maxpdv = 1;
    let maxmana = 0;
    let classHandicap = 7;
    let str_bonus = 0;
    let dex_bonus = 0;
    let con_bonus = 0;
    let int_bonus = 0;
    let mana_multiplier = 0; // multiplicateur mana
    let pdv_monstre = 0;
    let armClass_monstre = 10;
    let type_monstre = 'zabusa';
    let attbonus_monstre = 0;//calcul chance de hit monstre sur hero avec d20
    let degatbonus_monstre = 0;
    let xp_monstre = 10;
    let d20 // random nb pour calculs
    let d4
    let d6
    let d8
    let d12
    let arm_class = 10; // classe armure
    let nbSalle = 0; //nb salle pour stat fin
    let attbonus = 0; //calcul chance de hit hero sur monstre avec d20
    let att_multiplier = 2; //permet le calcul de rng sur hit avec lvl et ?_bonus
    let arm_multiplier = 0; //permet le calcul de arm_class en fonction du type d'armure
    let xp = 0;
    let salleImg = 'generic';
    let degat_hero;
    let degat_bonus;
    let armor = 10;
    let spell_degat;
    let arm = 0;
    let arm_count = 0;
    let droparray;
    let lootdrop;
    let salles;
    let potions = 1;
    
    // cration popup
    let loot = function(){
      $('body').append("<div class='itempopup'><div class='lootpopup'><div class='item " + lootdrop + "'></div><p>Vous avez trouvé <br>[" + lootdrop + "]<br>Voulez le mettre dans votre inventaire ?<br><button id='loot_oui'>Oui</button><button id='loot_non'>Non</button></p></div></div>");
   };
        
  
  
    function itemloot() {
      //items dropables 
      if (d6 == 1) { //1H
        droparray = Array("kunai", "epee", "arc", "samehada", "kusanagi", "totsuka", "shuriken", "kunai", "epee", "arc", "kusanagi");
        lootdrop = droparray[Math.floor(Math.random() * droparray.length)];
      } else if (d6 == 2) { //2H
        droparray = Array("yata");
        lootdrop = droparray[Math.floor(Math.random() * droparray.length)];
      } else if (d6 == 3) { //armures
        droparray = Array("cape", "cuir", "cotedemaille", "argent", "or", "diamant", "cape", "cuir", "argent");
        lootdrop = droparray[Math.floor(Math.random() * droparray.length)];
      } else if (d6 == 4) { //spells
        droparray = Array("katon", "chidori", "amaterasu", "Kotoamatsukami", "heal", "susano", "katon", "chidori", "heal", "Pikkingu", "Pikkingu");
        lootdrop = droparray[Math.floor(Math.random() * droparray.length)];
      } else { //potion
        lootdrop = "potion";
      }
    }
  
    //-------- Gestion hud joueur
    setInterval(function() {
      maxpdv = classHandicap + con_bonus + lvl;
      if (classehero == "Taijutsu") {
        maxmana = 0;
      } else {
        maxmana = Math.round(mana_multiplier * lvl) + (int_bonus*2);
        if (maxmana < 0) {
          maxmana = 0
        };
      }
  
      lvl = Math.round(1 + (xp / (100 + (xp / 4))));
      $('.hud_pdv').html(pdv);
      $('.hud_mana').html(mana);
      $('.max_pdv').html(maxpdv);
      $('.max_mana').html(maxmana);
      $('.hud_attBonus').html(degat_bonus);
      $('.hud_spellBonus').html(int_bonus);
      $('.hud_classArmure').html(arm_class);
      $('#lvl_hero').html(lvl);
      $('.hud_xp').html(xp);
      $('.hud_pot').html(potions);
      //variable de calcul RNG
      d20 = (Math.floor(Math.random() * 20) + 1);
      d4 = (Math.floor(Math.random() * 4) + 1);
      d6 = (Math.floor(Math.random() * 6) + 1);
      d8 = (Math.floor(Math.random() * 8) + 1);
      d12 = (Math.floor(Math.random() * 12) + 1);
  
      //initialiser img salle
      if (salles == 'monstre') {
        if (pdv_monstre > 0) {
          salleImg = type_monstre;
        } else {
          salleImg = 'generic';
        }
       }else if (salles == 'coffre') {
           salleImg = 'coffre';
        } else {
          salleImg = 'porte';
        }
  
      if (pdv > 0) {
        $('#IDsalleImg').attr("class",salleImg);
      } else {
        setTimeout(function() { //popup
         $('#IDsalleImg').attr("class","gameover");
        }, 1200);
      }
  
      if (arm_count < 1) {
        arm = 0;
      }
  
      //---------- Inventaire ----------//
    if (degat_bonus>-1){
      var plusmoins= '+'
    }else {
      plusmoins=''
    };
      
      if ($('#armes').val() == "kunai") {
        degat_hero = d4;
        degat_bonus = str_bonus;
        attbonus = Math.round((lvl / att_multiplier)) + str_bonus;
        $('.hud_degat').html('1 à 4 ' + '<span class="rouge">[ '+ plusmoins + degat_bonus + ' ]</span>');
      };
      if ($('#armes').val() == "epee") {
        degat_hero = d6;
        degat_bonus = str_bonus;
        attbonus = Math.round((lvl / att_multiplier)) + str_bonus;
        $('.hud_degat').html('1 à 6 ' + '<span class="rouge">[ '+ plusmoins + degat_bonus + ' ]</span>');
      };
      if ($('#armes').val() == "arc") {
        degat_hero = d6;
        degat_bonus = dex_bonus;
        attbonus = Math.round((lvl / att_multiplier)) + dex_bonus;
        $('.hud_degat').html('1 à 6 ' + '<span class="rouge">[ '+ plusmoins + degat_bonus + ' ]</span>');
      };
      if ($('#armes').val() == "samehada") {
        degat_hero = d8;
        degat_bonus = str_bonus;
        attbonus = Math.round((lvl / att_multiplier)) + str_bonus;
        $('.hud_degat').html('1 à 8 ' + '<span class="rouge">[ '+ plusmoins + degat_bonus + ' ]</span>');
      };
      if ($('#armes').val() == "kusanagi") {
        degat_hero = d8;
        degat_bonus = str_bonus;
        attbonus = Math.round((lvl / att_multiplier)) + str_bonus;
        $('.hud_degat').html('1 à 8 ' + '<span class="rouge">[ '+ plusmoins + degat_bonus + ' ]</span>');
      };
      if ($('#armes').val() == "totsuka") {
        degat_hero = d12;
        degat_bonus = str_bonus;
        attbonus = Math.round((lvl / att_multiplier)) + str_bonus;
        $('.hud_degat').html('1 à 12 ' + '<span class="rouge">[ '+ plusmoins + degat_bonus + ' ]</span>');
      };
      if ($('#armes').val() == "shuriken") {
        degat_hero = d8;
        degat_bonus = dex_bonus;
        attbonus = Math.round((lvl / att_multiplier)) + dex_bonus;
        $('.hud_degat').html('1 à 8 ' + '<span class="rouge">[ '+ plusmoins + degat_bonus + ' ]</span>');
      };

      //2H//////
      if ($('#armes').children(':selected').hasClass('Arme2')) {
        $('#armes_secondaire').prop("disabled", true);
        $('#armes_secondaire').val("aucun");
      } else {
        $('#armes_secondaire').prop("disabled", false);
      }
      
      //Armure/////
      if (classehero == "Ninjutsu") {
        $('#armures').prop("disabled", true);
      } else {
        $('#armures').prop("disabled", false);
      }
      if (classehero == "Mangekyo") {
        $('.heavy').prop("disabled", true);
      } else {
        $('.heavy').prop("disabled", false);
      }
      if ($('#armures').val() == "aucun") {
        armor = 10;
        arm_class = armor + Math.round((arm_multiplier * (lvl / 2))) + dex_bonus + arm;
      };
      if ($('#armures').val() == "cape") {
        armor = 11;
        arm_class = armor + Math.round((arm_multiplier * (lvl / 2))) + dex_bonus + arm;
      };
      if ($('#armures').val() == "cuir") {
        armor = 12;
        arm_class = armor + Math.round((arm_multiplier * (lvl / 2))) + dex_bonus + arm;
      };
      if ($('#armures').val() == "cotedemaille") {
        armor = 13;
        arm_class = armor + Math.round((arm_multiplier * (lvl / 2))) + dex_bonus + arm;
      };
      if ($('#armures').val() == "argent") {
        armor = 14;
        arm_class = armor + Math.round((arm_multiplier * (lvl / 2)));
      };
      if ($('#armures').val() == "or") {
        armor = 15;
        arm_class = armor + Math.round((arm_multiplier * (lvl / 2)));
      };
      if ($('#armures').val() == "diamant") {
        armor = 16;
        arm_class = armor + Math.round((arm_multiplier * (lvl / 2)));
      };
      //bouclier//
      if ($('#armes_secondaire').val() == "yata") {
        arm_class = arm_class + 2;
      };

      //spells/////
      if (int_bonus>-1){
        var sp_plusmoins='+'
      } else {
        sp_plusmoins=''
      };
      
      if (classehero == "Taijutsu") {
        $('#spells').prop("disabled", true);
      } else {
        $('#spells').prop("disabled", false);
      }
      if ($('#spells').val() == "aucun") {
        spell_degat = 0;
        $('.hud_spellDegat').html('N/A');
      };
      if ($('#spells').val() == "katon") {
        spell_degat = d6 + int_bonus;
        $('.hud_spellDegat').html('1 à 6 ' + '<span class="rouge">[ '+ sp_plusmoins + int_bonus + ' ]</span>');
      };
      if ($('#spells').val() == "chidori") {
        spell_degat = (d6*2) + int_bonus;
        $('.hud_spellDegat').html('2 à 12 ' + '<span class="rouge">[ '+ sp_plusmoins + int_bonus + ' ]</span>');
      };
      if ($('#spells').val() == "amaterasu") {
        spell_degat = (d6*3) + int_bonus;
        $('.hud_spellDegat').html('3 à 18 ' + '<span class="rouge">[ '+ sp_plusmoins + int_bonus + ' ]</span>');
      };
      if ($('#spells').val() == "Kotoamatsukami") {
        spell_degat = (d12*2) + int_bonus;
        $('.hud_spellDegat').html('2 à 24 ' + '<span class="rouge">[ '+ sp_plusmoins + int_bonus + ' ]</span>');
      };
      if ($('#spells').val() == "heal") {
        spell_degat = 0;
          $('.hud_spellDegat').html('N/A');
      };
      if ($('#spells').val() == "susano") {
        spell_degat = 0;
          $('.hud_spellDegat').html('N/A');
      };
      if (potions > 0){
        $('#potion_hero').prop("disabled", false);
      }else{
        $('#potion_hero').prop("disabled", true);
      }
  
      //------------- fin inventaire -------------///
  
      //gameover
      if (pdv < 1) {
        setTimeout(function() {
          $('#desc_pieces').html("Vous êtes mort.<br>Vous avez survécu à " + nbSalle + " salles.<hr><span class='jaune'>Cliquer n'importe où pour recommencer.</span>");
          $('.options_hero').detach();
          $('#showInv').detach();
          $('body').click(function() {
          window.location.href=window.location.href;
          });
        }, 1200);
      }

      //WIN
      if (type_monstre == 'madara' && pdv_monstre < 1) {
        setTimeout(function() {
          $('#desc_pieces').html("Vous avez vaincu MADARA UCHIHA !<br>Et avez parcouru " + nbSalle + " lieux.<hr><span class='jaune'>Voulez vous recommencer avec une autre classe ?</span>");
          $('.options_hero').detach();
          $('#showInv').detach();
          $('body').click(function() {
          window.location.href=window.location.href;
          });
        }, 1200);
      }
  
    }, 500);
    //--------- fin introduction ---------//
  
    //------- creation stats hero -------//
    $('#rdm_stat').click(function() {
      $('#valider').prop("disabled", false);
      if (rerollstat == 1) {
        $('#rdm_stat').remove();
      };
      if (rerollstat > 0) {
        str_reroll = Math.floor(Math.random() * 50) + 1; // basse * 10 mis à 50 pour le test
        dex_reroll = Math.floor(Math.random() * 50) + 1;
        int_reroll = Math.floor(Math.random() * 50) + 1;
        con_reroll = Math.floor(Math.random() * 50) + 1;
  
        str = str_reroll + str_base;
        dex = dex_reroll + dex_base;
        int = int_reroll + int_base;
        con = con_reroll + con_base;
        $('#str_value').html(str);
        $('#dex_value').html(dex);
        $('#intel_value').html(int);
        $('#con_value').html(con);
  
        rerollstat -= 1;
        $('#rdm_stat').html('Vos stats ne vous conviennent pas ? (' + rerollstat + ' essaies restant)');
      };
    }); //fin creation stats hero

    //-------- choix race --------//
    $('#choix_race').change(function() {
      if ($(this).val() == "naruto") {
        str_base = 6;
        dex_base = 6;
        con_base = 6;
        int_base = 6;
        racehero = 'naruto';
      };
      if ($(this).val() == "sasuke") {
        str_base = 6;
        dex_base = 10;
        con_base = 4;
        int_base = 10;
        racehero = 'sasuke';
      };
      if ($(this).val() == "sakura") {
        str_base = 8;
        dex_base = 4;
        con_base = 1;
        int_base = 4;
        racehero = 'sakura';
      };
  
      str = str_reroll + str_base;
      dex = dex_reroll + dex_base;
      int = int_reroll + int_base;
      con = con_reroll + con_base;
      $('#str_value').html(str);
      $('#dex_value').html(dex);
      $('#intel_value').html(int);
      $('#con_value').html(con);
    }); //-------- fin choix race --------//
  
    //-------- choix classe --------//
    $('#choix_classe').change(function() { 
      if ($(this).val() == "Taijutsu") {
        classHandicap = 7; 
        mana_multiplier = 0;
        att_multiplier = 2;
        arm_multiplier = 0;
        classehero = 'Taijutsu';
        $('#armes').html('<option value="epee">epee</option>');
          $('#armures').html('<option value="cape">cape</option>');
        $('#spells').html('<option value="aucun">aucun</option>');
      };
      if ($(this).val() == "Ninjutsu") {
        classHandicap = 5;
        mana_multiplier = 1;
        att_multiplier = 4;
        arm_multiplier = 0;
        classehero = 'Ninjutsu';
        $('#armes').html('<option value="kunai">kunai</option>');
        $('#spells').html('<option value="katon">katon</option><option value="heal">heal</option><option value="chidori">chidori</option>');
       $('#armures').html('<option value="aucun">aucun</option>');
      };
      if ($(this).val() == "Mangekyo") {
        classHandicap = 6;
        mana_multiplier = 1;
        att_multiplier = 3;
        arm_multiplier = .5;
        classehero = 'Mangekyo';
        $('#armes').html('<option value="arc" class="Arme2">arc</option><option value="kunai">kunai</option>');
        $('#spells').html('<option value="katon">katon</option>');
        $('#armures').html('<option value="aucun">aucun</option>');
      };
    }); // -------- fin choix de classe --------//
  
    $('#valider').click(function() {
      //creation stats + bonus = total
      if (str + dex + int + con > 24) {
        str_bonus = Math.round((str - 11) / 2);
        dex_bonus = Math.round((dex - 11) / 2);
        int_bonus = Math.round((int - 11) / 2);
        con_bonus = Math.round((con - 11) / 2);
        pdv = classHandicap + con_bonus + lvl;
        maxpdv = classHandicap + con_bonus + lvl;
        if (classehero == "Taijutsu") {
          mana = 0;
          maxmana = mana;
        } else {
          mana = Math.round(mana_multiplier * lvl) + (int_bonus*2);
          maxmana = mana;
        };
        if (mana < 0) {
          mana = 0
        };
        nomhero = $('#nomhero_input').val();
        $('#hud_heroname').html(nomhero);
        $('.hud_pdv').html(pdv);
        $('.hud_mana').html(mana);
        spritehero = $('#choix_race').val();
        $('.sprite_hero').addClass(spritehero);
        $('#race_hero').html(racehero);
        $('#classe_hero').html(classehero);
        $('#lvl_hero').html(lvl);
        $('#str_hero').html(str);
        $('#dex_hero').html(dex);
        $('#intel_hero').html(int);
        $('#con_hero').html(con);
        $('#str_hero_b').html(' [ ' + str_bonus + ' ]');
        $('#dex_hero_b').html(' [ ' + dex_bonus + ' ]');
        $('#intel_hero_b').html(' [ ' + int_bonus + ' ]');
        $('#con_hero_b').html(' [ ' + con_bonus + ' ]');
        $('.creer_hero').detach();
        
        //retire spell à la classe Taijutsu
        if (classehero == "Taijutsu") {
          $('#spell_hero').prop("disabled", true);
        } else {
          $('#spell_hero').prop("disabled", false);
        }
  
      } else {
        alert('Vous devez reroll vos stats prédéfinies avant de pouvoir commencer !');
      }
    });

//----------------------------------------- GAME INTERFACE -----------------------------------------//

    //ouvrir inventaire
    let animationMenu = 0
    $('#showInv').click(function() {
      if (animationMenu == 1) {
        $(".ouvertureInventaire").animate({
          left: '-300'
        }, 350);
        animationMenu = 0
      } else {
        $(".ouvertureInventaire").animate({
          left: '0'
        }, 350);
        animationMenu = 1
      }
    }); //fin ouvrir inventaire
    
    //---------- Action ouvrir hero ----------//
    $('#ouvrir_hero').click(function() {
      let str1 = $('#desc_pieces').text();
      let str2 = "porte";
      let str3 = "coffre";
      let str4 = "monstre";
      let str5 = "locked";
      let str6 = "obstacle";
  
      if (str1.indexOf(str2) != -1) { //si c'est une porte
        let results = Array("Vous parvenez a ouvrir et passez.", "Elle est fermée.<em>locked</em>");
        let output = results[Math.floor(Math.random() * results.length)];
        $('#desc_pieces').html(output);
  
      } else if (str1.indexOf(str3) != -1) { //si c'est un coffre
        let results = Array("Vous ouvrez et trouvez de l'équipements !", "Vous essayez de l'ouvrir, mais n'y arrivé pas.<em>obstacle</em>");
        let output = results[Math.floor(Math.random() * results.length)];
        $('#desc_pieces').html(output);
        if (output == "Vous ouvrez et trouvez de l'équipements !") {
          setTimeout(function() { //loot popup
            itemloot(1, false);
            loot();
          }, 600); //loot popup
        };
  
      } else if (str1.indexOf(str4) != -1) { //si il y a un monstre
        $('#desc_pieces').html("Il n'y a rien à ouvir ici... Vous faites face à " + type_monstre + "<em>monstre</em>.");
  
      } else if (str1.indexOf(str5) != -1) { //si c'est une porte fermé
        $('#desc_pieces').html("Elle semble toujours fermé<em>locked</em>.");
  
      } else if (str1.indexOf(str6) != -1) { //si coffre fermé
        $('#desc_pieces').html("Cela semble toujours verrouilé<em>obstacle</em>.");
  
      } else { //si il n'y a rien
        $('#desc_pieces').html("Il n'y a rien à ouvrir ici.");
      }
    }); //---------- fin action Ouvrir hero ----------//
  

    //---------- action crocheter hero ----------//
    $('#crocheter_hero').click(function() {
      let str1 = $('#desc_pieces').text();
      let str2 = "porte";
      let str3 = "coffre";
      let str4 = "locked";
      let str5 = "obstacle";
      let str6 = "monstre";
  
      if (str1.indexOf(str2) != -1) { //si c'est une porte
        $('#desc_pieces').html("Vous n'êtes même pas sûr que la porte soit fermée.<em>locked</em>");
  
      } else if (str1.indexOf(str3) != -1) { //si c'est un coffre
        $('#desc_pieces').html("Vous n'êtes même pas sûr que le coffre soit fermée.<em>monstre</em>");
  
      } else if (str1.indexOf(str4) != -1) { //si la porte est fermé
        let lockpick = d20 + dex_bonus
        if (lockpick > 10) { //action crochetage = succée
          $('#desc_pieces').html("Vous crochetez la serrure !"); /////////////////////////
        } else { //sinon = echec
          let degat_piege = d4;
          $('#desc_pieces').html("Ca s'ouvre ! Mais vous recevez " + degat_piege + " de dégat(s) en tombant sur un piège !");
          pdv -= degat_piege;
        }
  
      } else if (str1.indexOf(str5) != -1) { //si coffre fermé
        let lockpick = d20 + dex_bonus
        if (lockpick > 10) { //action crochetage = succée
          $('#desc_pieces').html("Vous parvenez à crocheter la serrure, et trouvez de l'équipements !");
          setTimeout(function() { // loot popup
            itemloot(1, false);
            loot();
          }, 600); //loot loot popup
        } else { //sinon = echec
          let degat_piege = d4;
          $('#desc_pieces').html("C'etait un piège, vous perdez " + degat_piege + " de vies.");
          pdv -= degat_piege;
        }
  
      } else if (str1.indexOf(str6) != -1) { //si c'est un monstre
        $('#desc_pieces').html("Vous ne pouvez pas faire cela maintenant... concentrez vous sur " + type_monstre + "<em>monstre</em>.");
  
      } else { //rien
        $('#desc_pieces').html("Il n'y a rien à crocheter ici.");
      }
    }); //----------  fin action crocheter ----------//
    

    // ---------- action attaquer hero ----------//
    $(document).on("click", "#attaquer_hero", function() {
      let str1 = $('#desc_pieces').text();
      let str2 = "locked"; //porte fermé
      let str3 = "obstacle"; //coffre fermé
      let str4 = "monstre"; //monstre
      let str5 = "porte"; //porte
      let str6 = "coffre"; //coffre
  
      if (str1.indexOf(str2) != -1) { //si c'est une porte fermé
        let rng_breakP = d20 + str_bonus
        if (rng_breakP > 10) { // succee
          $('#desc_pieces').html('Merde... Tu la vraiment cassez !');
        } else { //echec
          let degat_porte = Math.round((d4) / 2);
          $('#desc_pieces').html("Vous tentez de passer en force,  mais vous vous ecrasez dessus et perdez " + degat_porte + " de vie(s)<em>locked</em>.");
          pdv -= degat_porte;
        }

      } else if (str1.indexOf(str3) != -1) { //si c'est un coffre fermé
        let rng_breakC = d20 + str_bonus
        if (rng_breakC > 15) { //succee
          $('#desc_pieces').html('Vous parvenez à briser la serrure !');
          setTimeout(function() { //popup
            itemloot(1, false);
            loot();
          }, 600); //popup
        } else { //echec
          $('#desc_pieces').html("Ce n'est pas la bonne méthode ! vous risqueriez d'endommager son contenu.");
        }
  
      } else if (str1.indexOf(str5) != -1) { //Si c'est une porte 
        $('#desc_pieces').html("Essaye d'ouvir avant <em>porte</em>!");
  
      } else if (str1.indexOf(str6) != -1) { //si c'est un coffre 
        $('#desc_pieces').html("Essaye d'ouvrir avant <em>coffre</em>!");
  
      } else if (str1.indexOf(str4) != -1) { // si c'est un monstre     
        let rng_hit = d20 + attbonus;
        let degat_cible = degat_hero + degat_bonus;
        if (rng_hit > armClass_monstre) { // attaque hero
          $('#desc_pieces').html("Vous avez attaquez " + type_monstre + " <em>monstre</em>, et lui infligez " + degat_cible + " de dégat(s).");
          pdv_monstre -= degat_cible;
        } else {
          $('#desc_pieces').html("Vous avez attaquez " + type_monstre + " <em>monstre</em>, mais il esquive votre attaque !");
        } //fin attaque hero
  
        $('#attaquer_hero').prop("disabled", true);
        $('#spell_hero').prop("disabled", true);
  
        setTimeout(function() { //attaque monstre
          if (pdv_monstre < 1) { //monstre tué
            $('#desc_pieces').html("Vous avez vaincu " + type_monstre + " !");
            xp += xp_monstre;
            if (d4 == 4) {
              setTimeout(function() { //loot popup
                itemloot(1, false);
                loot();
              }, 600); //fin loot popup
            }
          } else {
            let degat_hero = d20 + attbonus_monstre;
            let degat_monstre = d6 + degatbonus_monstre;
            if (degat_monstre < 1) {
              degat_monstre = 1
            };
            if (degat_hero > arm_class) {
              $('#desc_pieces').html(type_monstre + "<em>monstre</em> vous attaque et vous inflige " + degat_monstre + " de dégat(s) !");
              pdv -= degat_monstre;
            } else {
              $('#desc_pieces').html(type_monstre + "<em>monstre</em> vous attaque mais vous esquivez !");
            }
          }
          $('#attaquer_hero').prop("disabled", false);
          if (classehero !== 'Taijutsu') {
            $('#spell_hero').prop("disabled", false);
          }
        }, 1200); //fin attaque monstre
  
      } else { //si on attaque dans rien
        $('#desc_pieces').html("Attaquer ici n'a aucun effet.");
      }
  
    }); //---------- fin action attaque hero ----------//
  

    //---------- Action attaque special hero ----------//
    $('#spell_hero').click(function() {
      let str1 = $('#desc_pieces').text();
      let str2 = "locked";
      let str3 = "obstacle";
      let str4 = "monstre";
      let str5 = "porte";
      let str6 = "coffre";
  
      if (str1.indexOf(str2) != -1) { //--- Si c'est une porte fermé ---//
        if ($('#spells').val() == 'Pikkingu') {
          if (mana > 1) {
            $('#desc_pieces').html("Votre magie parvient à ouvrir la porte !");
            mana -= 2
          } else { // si pas assez de mana
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser cette compétence<em>locked</em>.");
          }
  
        } else if ($('#spells').val() == 'heal') {
          if (mana > 0) { //sort de heal
            let heal = (d4) + int_bonus;
            pdv += heal;
            $('#desc_pieces').html("Vous utilisé votre sort de soin et récupéré " + heal + " points de vie.<em>locked</em>");
            if (pdv > maxpdv) {
              pdv = maxpdv;
            }
            mana -= 1;
          } else { //si pas assez de mana
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser cette compétence.<em>locked</em>");
          }
  
        } else if ($('#spells').val() == 'susano') {
          if (mana > 2) { //sort d'armure
            arm = int_bonus;
            arm_count = int_bonus + lvl;
            $('#desc_pieces').html("Vous activer votre susano qui vous servira de protection.<em>locked</em>");
            if (pdv > maxpdv) {
              pdv = maxpdv;
            }
            mana -= 3;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser cette compétence.<em>locked</em>");
          }
  
        } else { //si pikkingu non équipé
          $('#desc_pieces').html("Votre spell équipé ne permet pas de crocheter la serrure<em>locked</em>.");
        }
  
      } else if (str1.indexOf(str3) != -1) { //--- Si c'est un coffre fermé ---//
        if ($('#spells').val() == 'Pikkingu') {
          if (mana > 1) {
            $('#desc_pieces').html("Votre magie vous a permit l'ouvrir ! Vous pouvez récupérer l'quipement.");
            setTimeout(function() { //popup
              itemloot(1, false);
            loot();
            }, 600); //popup
            mana -= 2
          } else { //si pas assez de mana
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser cette compétence<em>obstacle</em>.");
          }
        } else if ($('#spells').val() == 'heal') {
          if (mana > 0) { //sort de heal
            let heal = (d4) + int_bonus;
            pdv += heal;
            $('#desc_pieces').html("Vous utilisé votre sort de soin et récupéré " + heal + " points de vie.<em>obstacle</em>");
            if (pdv > maxpdv) {
              pdv = maxpdv;
            }
            mana -= 1;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser cette compétence.<em>obstacle</em>");
          }
  
        } else if ($('#spells').val() == 'susano') {
          if (mana > 2) { //sort d'armure
            arm = int_bonus;
            arm_count = int_bonus + lvl;
            $('#desc_pieces').html("Vous activer votre susano qui vous servira de protection.<em>obstacle</em>");
            if (pdv > maxpdv) {
              pdv = maxpdv;
            }
            mana -= 3;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser cette compétence.<em>obstacle</em>");
          }
  
        } else { //si pikkingu pas équipé
          $('#desc_pieces').html("Votre spell équipé ne permet pas de crocheter la serrure<em>obstacle</em>.");
        }


        //--- si c'est une porte ---//
      } else if (str1.indexOf(str5) != -1) { 
        if ($('#spells').val() == 'heal') {
          if (mana > 0) {
            let heal = (d4) + int_bonus;
            pdv += heal;
            $('#desc_pieces').html("Vous utilisé votre sort de soin et récupéré " + heal + " points de vie.<em>porte</em>");
            if (pdv > maxpdv) {
              pdv = maxpdv;
            }
            mana -= 1;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser cette compétence.<em>porte</em>");
          }
  
        } else if ($('#spells').val() == 'susano') {
          if (mana > 2) {
            arm = int_bonus;
            arm_count = int_bonus + lvl;
            $('#desc_pieces').html("Vous activer votre susano qui vous servira de protection.<em>porte</em>");
            if (pdv > maxpdv) {
              pdv = maxpdv;
            }
            mana -= 3;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser cette compétence.<em>porte</em>");
          }
  
        } else { //si pikkingu pas équipé
          $('#desc_pieces').html("Votre spell équipé ne permet pas de crocheter la serrure<em>porte</em>.");
        }

        
        //--- Si il y a un coffre ---//
      } else if (str1.indexOf(str6) != -1) {    
        if ($('#spells').val() == 'heal') {
          if (mana > 0) {
            let heal = (d4) + int_bonus;
            pdv += heal;
            $('#desc_pieces').html("Vous utilisé votre sort de soin et récupéré " + heal + " points de vie.<em>coffre</em>");
            if (pdv > maxpdv) {
              pdv = maxpdv;
            }
            mana -= 1;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser cette compétence.<em>coffre</em>");
          }
  
        } else if ($('#spells').val() == 'susano') {
          if (mana > 2) {
            arm = int_bonus;
            arm_count = int_bonus + lvl;
            $('#desc_pieces').html("Vous activer votre susano qui vous servira de protection.<em>coffre</em>");
            if (pdv > maxpdv) {
              pdv = maxpdv;
            }
            mana -= 3;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser cette compétence.<em>coffre</em>");
          }
  
        } else { //si pikkingu n'est pas équipé
          $('#desc_pieces').html("Votre spell équipé ne permet pas de crocheter la serrure<em>coffre</em>.");
        }
  
      } else if (str1.indexOf(str4) != -1) { //--- Si il y a un monstre ---//
        if ($('#spells').val() == 'katon') { //action spell --> katon
          if (mana > 0) {
            $('#desc_pieces').html("Vous brulez " + type_monstre + "<em>monstre</em> avec votre KATON, et lui infligez " + spell_degat + " de dégat(s).");
            pdv_monstre -= spell_degat;
            mana -= 1;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour lancer votre KATON sur " + type_monstre + "<em>monstre</em>.");
          }
        }; //fin katon
  
        if ($('#spells').val() == 'chidori') { //action spell --> chidori
          if (mana > 1) {
            $('#desc_pieces').html("Vous foudroyez " + type_monstre + "<em>monstre</em> avec votre CHIDORI, et lui infligez " + spell_degat + " de dégat(s).");
            pdv_monstre -= spell_degat;
            mana -= 2;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser votre CHIDORI sur " + type_monstre + "<em>monstre</em>.");
          }
        }; //fin chidori
  
        if ($('#spells').val() == 'amaterasu') { //action spell --> amaterasu
          if (mana > 2) {
            $('#desc_pieces').html("Vous activer votre AMATERASU sur " + type_monstre + "<em>monstre</em> et le consumme petit à petit, et lui inflige " + spell_degat + " de dégat(s) ! Il parvient tout de même à éteindre les flammes noirs...");
            pdv_monstre -= spell_degat;
            mana -= 3;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser votre AMATERASU sur " + type_monstre + "<em>monstre</em>.");
          }
        }; //fin amaterasu
  
        if ($('#spells').val() == 'Kotoamatsukami') { //action spell --> Kotoamatsukami
          if (mana > 3) {
            $('#desc_pieces').html("Vous plongez " + type_monstre + "<em>monstre</em> dans les lymbes, et lui infligez " + spell_degat + " de dégat(s). Personne ne peut y survivre...");
            pdv_monstre -= spell_degat;
            mana -= 4;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour activer votre KOTOAMATSUKAMI sur " + type_monstre + "<em>monstre</em>.");
          }
        }; //fin Kotoamatsukami
  
        if ($('#spells').val() == 'heal') { //action spell --> heal
          if (mana > 0) {
            let heal = (d4) + int_bonus;
            pdv += heal;
            $('#desc_pieces').html("Vous utilisé votre sort de soin et récupéré " + heal + " points de vie.<em>monstre</em>");
            if (pdv > maxpdv) {
              pdv = maxpdv;
            }
            mana -= 1;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser cette compétence.<em>monstre</em>");
          }
        }; //fin heal
  
        if ($('#spells').val() == 'susano') { //action spell --> susano
          if (mana > 2) {
            arm = int_bonus;
            arm_count = int_bonus + lvl;
            $('#desc_pieces').html("Vous activer votre susano qui vous servira de protection.<em>monstre</em>");
            if (pdv > maxpdv) {
              pdv = maxpdv;
            }
            mana -= 3;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser voutre SUSANÔ.<em>monstre</em>");
          }
        }; //fin susano
  
        if ($('#spells').val() == 'Pikkingu') { //action spell --> Pikkingu
          if (mana > 1) {
            $('#desc_pieces').html("Vous utilisez PIKKINGU sur " + type_monstre + "<em>monstre</em>, mais c'est innéficace !");
            mana -= 2;
          } else {
            $('#desc_pieces').html("Vous n'avez pas assez de mana pour utiliser cette compétence sur" + type_monstre + "<em>monstre</em>.");
          }
        }; //fin Pikkingu
  
        if ($('#spells').val() == 'aucun') { //action spell --> aucun
          $('#desc_pieces').html("Vous n'avez pas compétences équipé, " + type_monstre + "<em>monstre</em> c'est au tour de votre adversaire !");
        }; //fin no spell
  
        $('#spell_hero').prop("disabled", true);
        $('#attaquer_hero').prop("disabled", true);
  
        setTimeout(function() { // attaque monstre
          if (pdv_monstre < 1) { //monstre tué
            $('#desc_pieces').html("Vous avez vaincu " + type_monstre + " !");
            xp += xp_monstre;
            if (d4 == 4) {
              setTimeout(function() { //popup
                itemloot(1, false);
                loot();
              }, 600); //popup
            }
          } else {
            let degat_hero = d20 + attbonus_monstre;
            let degat_monstre = d6 + degatbonus_monstre;
            if (degat_monstre < 1) {
              degat_monstre = 1
            };
            if (degat_hero > arm_class) {
              $('#desc_pieces').html(type_monstre + "<em>monstre</em> attaque et vous retire " + degat_monstre + " point(s) de vie !");
              pdv -= degat_monstre;
            } else {
              $('#desc_pieces').html(type_monstre + "<em>monstre</em> vous attaque mais vous esquivez !");
            }
          }
          if (classehero !== 'Taijutsu') {
            $('#spell_hero').prop("disabled", false);
          }
          $('#attaquer_hero').prop("disabled", false);
        }, 1200); //fin attaque monstre
  
      } else { //si attaque special dans rien
        $('#desc_pieces').html("Il n'y a rien ç attaquer ici");
      }
  
    }); //---------- fin user spell ----------//


    //---------- Action poursuivre progression hero ----------//
    $('#avancer_hero').click(function() {
      let str1 = $('#desc_pieces').text();
      let str2 = "porte";
      let str3 = "locked";
      let str4 = "monstre";
  
      if (str1.indexOf(str2) != -1) { //--- Si c'est une porte ---//
        $('#desc_pieces').html("La porte est fermée !");
  
      } else if (str1.indexOf(str3) != -1) { //--- si c'est une porte est fermé ---//
        $('#desc_pieces').html("Vous êtes toujours bloqué dans la pièce.<em>locked</em>");
  
      } else if (str1.indexOf(str4) != -1) { //--- si c'est un monstre ---//
        $('#desc_pieces').html("Vous ne pouvez pas fuir face à" + type_monstre + " <em>monstre</em> sans le combattre.");
  
      } else { //--- progresser vers une autre pièce ---//
        $('#imgSalleEffect').addClass('.imgEffect');
        setTimeout(function() { //effet
          $('#imgSalleEffect').removeClass('.imgEffect');
        }, 1000);
        nbSalle += 1;
        arm_count -= 1;
  
        let sallearray = Array("coffre", "porte", "porte", "monstre", "monstre");
        salles = sallearray[Math.floor(Math.random() * sallearray.length)];
        //choix du monstre a affronter
        let monstre_array = Array(1, 1, 2, 2, 3, 3, 4);
        let choix_monstre = (monstre_array[Math.floor(Math.random() * monstre_array.length)]) * lvl;
  
        if (choix_monstre < 4) { //0-3
          type_monstre = "zabusa";
          armClass_monstre = 8;
          pdv_monstre = 4;
          attbonus_monstre = -3;
          degatbonus_monstre = -d4;
          xp_monstre = 2000;
        }
        if (choix_monstre > 3 && choix_monstre < 7) { //3-6
          type_monstre = "orochimaru";
          armClass_monstre = 10;
          pdv_monstre = 5;
          attbonus_monstre = 0;
          degatbonus_monstre = 0;
          xp_monstre = 4000;
        }
        if (choix_monstre > 6 && choix_monstre < 11) { //7-10
          type_monstre = "obito";
          armClass_monstre = 12;
          pdv_monstre = 8;
          attbonus_monstre = 1;
          degatbonus_monstre = 2;
          xp_monstre = 9000;
        }
        if (choix_monstre > 10 && choix_monstre < 15) { //11-14
          type_monstre = "itachi";
          armClass_monstre = 14;
          pdv_monstre = 12;
          attbonus_monstre = 3;
          degatbonus_monstre = 2;
          xp_monstre = 15000;
        }
        if (choix_monstre > 14 && choix_monstre < 19) { //15-18
          type_monstre = "minato";
          armClass_monstre = 16;
          pdv_monstre = 20;
          attbonus_monstre = 5;
          degatbonus_monstre = 2;
          xp_monstre = 30000;
        }
        if (choix_monstre > 18) { //19+
          type_monstre = "madara";
          armClass_monstre = 20;
          pdv_monstre = 40;
          attbonus_monstre = 8;
          degatbonus_monstre = 2;
          xp_monstre = 700;
        }
  
        // générer phrase en cas de salle monstre
        if (salles == "monstre") {
          $('#desc_pieces').html("<strong>" + type_monstre + "</strong>" + " <em>monstre</em> vous bloque la route !");

        // générer phrase en cas de salle simple
        }else if (salles == "porte") {
          let type_salle = [' hall ', ' chambre ', ' cave ', ' grenier ', ' couloir '][Math.floor(Math.random() * 5)];
          let adj_salle = [' étrange', ' moisi(e)', ' abandonné(e)', ' sale', ' sombre', ' etouffant'][Math.floor(Math.random() * 6)];
          let adj_porte = [' en bois', ' renforcée', ' en métal', ' rouillée', ' abimée'][Math.floor(Math.random() * 5)];
          $('#desc_pieces').html('Vous trouvez un(e)' + type_salle + 'qui semble' + adj_salle + ". Et vous trouver une porte" + adj_porte + " qui vous bloque le passage.");

        // générer phrase en cas de salle de coffre
        }else{
            let coffre_pos = [' au centre de ', ' dans le coin de ', ' au fond de ', ' dans une armoire de ', ' dans le sous-sol de '][Math.floor(Math.random() * 5)];
            let coffre_adj = [' orné de joyaux', ' brillant', ' poussiéreux', ' en bois', ' rouillé'][Math.floor(Math.random() * 5)];
          $('#desc_pieces').html("Il y  a" + coffre_pos + "la pièce un coffre " + coffre_adj + ".");
        }
  
      }; //--- fin progresser vers une autre pièce ---//
    }); //---------- fin Action poursuivre progression hero ----------//
  
    //------------ popup -> prendre / laisser loot ------------//
    $(document).on("click", "#loot_oui", function() {
      if (lootdrop == "kunai" || lootdrop == "epee") {
        $('#armes').append('<option value="' + lootdrop + '">' + lootdrop + '</option>');
      } else if (lootdrop == "arc" || lootdrop == "samehada") {
        $('#armes').append('<option value="' + lootdrop + '" class="Arme2">' + lootdrop + '</option>');
      } else if (lootdrop == "kusanagi") {
        $('#armes').append('<option value="' + lootdrop + '" >' + lootdrop + '</option>');
      } else if (lootdrop == "totsuka" || lootdrop == "shuriken") {
        $('#armes').append('<option value="' + lootdrop + '" class="Arme2">' + lootdrop + '</option>');
      } else if (lootdrop == "cape" || lootdrop == "cuir" || lootdrop == "cotedemaille") {
        $('#armures').append('<option value="' + lootdrop + '">' + lootdrop + '</option>');
      } else if (lootdrop == "argent" || lootdrop == "or" || lootdrop == "diamant") {
        $('#armures').append('<option value="' + lootdrop + '" class="heavy">' + lootdrop + '</option>');
      } else if (lootdrop == "yata") {
        $('#armes_secondaire').append('<option value="' + lootdrop + '">' + lootdrop + '</option>');
      } else if (lootdrop == "katon" || lootdrop == "chidori" || lootdrop == "amaterasu" || lootdrop == "Kotoamatsukami" || lootdrop == "heal" || lootdrop == "susano" || lootdrop == "Pikkingu") {
        $('#spells').append('<option value="' + lootdrop + '">' + lootdrop + '</option>');
      } else {
      potions+=1;
      }
      $('.itempopup').detach();
    });
    $(document).on("click", "#loot_non", function() {
      $('.itempopup').detach();
    });
    
    $('#potion_hero').click(function(){
      if (potions>0){
        let pot_heal = (d4) * 2;
        let pot_spell = d6;
        pdv += pot_heal;
        if (pdv > maxpdv) {
          pdv = maxpdv;
        };
        mana += pot_spell;
        if (mana > maxmana) {
          mana = maxmana;
        };
        potions-=1;
      };
    });
  
  }); //------------ fin main ------------//